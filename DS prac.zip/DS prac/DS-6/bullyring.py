# Practical 6: Election Algorithms
# When a Coordinator (Master) server crashes, the other servers need to vote/elect a new one.

# -------------------------------
# 1. Bully Algorithm
# -------------------------------
# Rule: The biggest guy (highest ID) always wins.

# 'class' creates our blueprint for the algorithm
class BullyAlgorithm:
    
    # '__init__' runs when we create it. 'self' means 'this object'.
    def __init__(self, processes, coordinator=None):
        self.processes = processes # Save the list of servers
        
        # 'max()' is a Python tool that finds the biggest number in a list.
        # We say: If a coordinator isn't given, just pick the highest ID.
        self.coordinator = coordinator if coordinator else max(processes)

    # A simple function to check if a computer is in our list (is it alive?)
    def is_alive(self, process_id):
        # 'in' checks if 'process_id' exists inside the 'processes' list
        return process_id in self.processes

    # This function is called when a server starts an election
    def hold_election(self, initiator):
        print(f"\nProcess {initiator} starts election.")

        # This looks tricky, but it's called a 'List Comprehension'.
        # It means: Go through every server 'p' in our list. If 'p' is bigger than the initiator, save it.
        higher_processes = [p for p in self.processes if p > initiator]

        # 'if not' checks if the list of higher servers is empty.
        if not higher_processes:
            # If empty, nobody is bigger than me. I win!
            self.coordinator = initiator
            print(f"Process {initiator} becomes new coordinator.")
            return # 'return' means stop running the rest of the function right here.

        # 'for' loops through the list of bigger guys we found
        for p in higher_processes:
            print(f"Election message sent from {initiator} to {p}")

        # Now we check which of those bigger guys are actually alive
        responses = [p for p in higher_processes if self.is_alive(p)]

        # If anyone responded...
        if responses:
            print(f"Responses received from {responses}")
            # Find the biggest one that replied using 'max()'
            highest = max(responses)
            # Make that biggest guy hold a new election (this is called Recursion - calling a function inside itself)
            self.hold_election(highest) 
        else:
            # If no one replied, they must all be dead. I become the coordinator.
            self.coordinator = initiator
            print(f"Process {initiator} becomes new coordinator.")

# -------------------------------
# 2. Ring Algorithm
# -------------------------------
# Rule: Everyone passes their ID in a circle. The highest ID in the circle wins.

class RingAlgorithm:
    def __init__(self, processes):
        # 'sorted()' is a built-in tool that puts our list in ascending order (1, 2, 3...)
        # This ensures they form a proper circle
        self.processes = sorted(processes)
        self.coordinator = None # 'None' means empty / we don't have one yet

    def hold_election(self, initiator):
        print(f"\nProcess {initiator} starts election.")

        # Create an empty list to keep track of everyone who touches the message
        election_list = []
        
        # '.index()' finds where the initiator is in our list (e.g., are they at position 0, 1, or 2?)
        index = self.processes.index(initiator)

        # 'while True:' runs an infinite loop
        while True:
            # Get the ID of the current person holding the message
            current = self.processes[index]
            
            # '.append()' adds them to our tracking list
            election_list.append(current) 

            # Figure out the position of the next person in the circle using the '%' remainder math
            next_index = (index + 1) % len(self.processes)
            next_process = self.processes[next_index]

            print(f"Message passed from {current} to {next_process}")

            # Update our index to the next person for the next round of the loop
            index = next_index

            # 'if' checks if the message made a full circle and got back to the initiator
            if self.processes[index] == initiator:
                break # 'break' breaks us out of the infinite 'while True' loop

        # Now that the loop is broken, find the biggest number in our tracking list
        winner = max(election_list)
        self.coordinator = winner

        print(f"Process {winner} is elected as coordinator.")

# -------------------------------
# Main Program Interface
# -------------------------------

# 'print' puts text on the screen
print("1. Bully Algorithm")
print("2. Ring Algorithm")

# 'input' waits for the user to type. 'int' converts it to a number.
choice = int(input("Enter choice: "))

# 'if' checks what the user chose
if choice == 1:
    processes = [1, 2, 3, 5, 6] # The active servers
    
    # Create the Bully system
    bully = BullyAlgorithm(processes)

    initiator = int(input("Enter process ID to start election: "))
    # Start the election using the number the user typed
    bully.hold_election(initiator)

# 'elif' means "else if". If choice was 2 instead...
elif choice == 2:
    processes = [1, 2, 4, 6] 
    ring = RingAlgorithm(processes)

    initiator = int(input("Enter process ID to start election: "))
    ring.hold_election(initiator)

# If they typed something else like 5
else:
    print("Invalid Choice")
