# Distributed Systems Practicals - Cheat Sheet
This file contains the exact commands you need to run for every practical in your exam. Open your Command Prompt (cmd) and follow the instructions below.

---

## 📁 Practical 1: Java RMI (Arithmetic Service)
1. Open terminal and navigate to the folder:
   ```cmd
   cd "DS practical 1"
   ```
2. Compile all Java files:
   ```cmd
   javac *.java
   ```
3. Start the Server (Opens in a new window):
   ```cmd
   start java ArithmeticServer
   ```
4. Run the Client:
   ```cmd
   java ArithmeticClient
   ```

---

## 📁 Practical 2: Java CORBA (Calculator App)
1. Navigate to the folder:
   ```cmd
   cd "DS prac 2"
   ```
2. Compile the IDL file:
   ```cmd
   idlj -fall Calculator.idl
   ```
3. Compile all Java files:
   ```cmd
   javac *.java CalculatorApp/*.java
   ```
4. Start the CORBA Naming Service (Opens in a new window):
   ```cmd
   start orbd -ORBInitialPort 1050
   ```
5. Start the Server (Opens in a new window):
   ```cmd
   start java CalculatorServer -ORBInitialPort 1050 -ORBInitialHost localhost
   ```
6. Run the Client:
   ```cmd
   java CalculatorClient -ORBInitialPort 1050 -ORBInitialHost localhost
   ```

---

## 📁 Practical 3: MPI in C (Parallel Computing)
*(Note: Use Ubuntu/Linux terminal for this, or MS-MPI on Windows)*
1. Navigate to the folder:
   ```cmd
   cd "DS-3"
   ```
2. Compile the C program:
   ```cmd
   mpicc sum_mpi.c -o sum_mpi
   ```
3. Run the program with 4 processes:
   ```cmd
   mpiexec -n 4 sum_mpi
   ```
   *(If on Ubuntu, use `mpirun -np 4 ./sum_mpi`)*

---

## 📁 Practical 4: Clock Synchronization (Berkeley Algorithm)
1. Navigate to the folder:
   ```cmd
   cd "DS-4"
   ```
2. Run the Python script:
   ```cmd
   python Assg4Simple.py
   ```

---

## 📁 Practical 5: Mutual Exclusion (Token Ring)
1. Navigate to the folder:
   ```cmd
   cd "DS-5"
   ```
2. Run the Python script:
   ```cmd
   python Assig5.py
   ```
*(Enter the number of processes when prompted, e.g., 4)*

---

## 📁 Practical 6: Election Algorithms (Bully & Ring)
1. Navigate to the folder:
   ```cmd
   cd "DS-6"
   ```
2. Run the Python script:
   ```cmd
   python bullyring.py
   ```
*(Choose 1 or 2, then enter an ID to start the election)*

---

## 📁 Practical 7: Web Service & Distributed Client
1. Navigate to the folder:
   ```cmd
   cd "DS-7"
   ```
2. Install the necessary Node.js packages (only need to do this once):
   ```cmd
   npm install
   ```
3. Start the Web Server:
   ```cmd
   node server.js
   ```
4. Leave the terminal open, open a web browser, and go to:
   **http://localhost:3000**
