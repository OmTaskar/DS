//What it is: The program the user runs to do the math.
//ORB is a middleware that helps the client and server communicate with each other.
import CalculatorApp.*;
import org.omg.CORBA.*; //Imports CORBA core classes Used for ORB (Object Request Broker)
import org.omg.CosNaming.*; //Imports CORBA Naming Service classes Used to find/register remote objects
 
public class CalculatorClient {
    public static void main(String args[]) {
        try {
            // Initialize the ORB (Object Request Broker)
            ORB orb = ORB.init(args, null);

//this code connects client to CORBA Name Service so it can find remote server objects.
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

           //Client finds and connects to remote Calculator object from CORBA Name Service
            Calculator calculator = CalculatorHelper.narrow(ncRef.resolve_str("Calculator"));
            
            // Step 4: Perform operations.
            // When we call calculator.add(), the numbers are actually sent over the network 
            // to the Server. The Server does the math and returns the answer.
            System.out.println("Addition (10 + 5): " + calculator.add(10, 5));
            System.out.println("Subtraction (10 - 5): " + calculator.subtract(10, 5));
            System.out.println("Multiplication (10 * 5): " + calculator.multiply(10, 5));

            try {
                // This one will succeed
                System.out.println("Division (10 / 2): " + calculator.divide(10, 2));
                
                // This one will trigger the custom DivisionByZero error we defined in the .idl file
                System.out.println("Division (10 / 0): " + calculator.divide(10, 0)); 
            } catch (DivisionByZero e) {
                // If the Server throws the error, the Client catches it here!
                System.out.println("Error: Division by zero is not allowed!");
            }

        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}