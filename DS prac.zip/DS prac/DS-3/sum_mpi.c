#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

// This program demonstrates Parallel Computing using MPI (Message Passing Interface).
// Instead of 1 program doing all the work, the work is split among multiple 'processes'.
int main(int argc, char* argv[]) {
    // 'rank' is the ID of the current process (e.g., Process 0, Process 1)
    // 'size' is the total number of processes running
    // 'N' is the total number of items we want to sum up
    int rank, size, N = 16;
    int array[N], local_sum = 0, total_sum = 0;
    
    // Step 1: Initialize the MPI environment
    MPI_Init(&argc, &argv);
    // Get this process's ID (rank)
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    // Get the total number of processes running
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Calculate how many numbers each process will add up (e.g., 16 / 4 processes = 4 numbers each)
    int elements_per_proc = N / size;
    int *sub_array = (int*)malloc(elements_per_proc * sizeof(int));

    // Process 0 acts as the 'Master'. It creates the full array of 16 numbers.
    if (rank == 0) {
        // Initialize the array with values [1, 2, 3, ... 16]
        for (int i = 0; i < N; i++) {
            array[i] = i + 1;  
        }
    }

    // Step 2: Scatter (distribute) the big array into smaller chunks for each process.
    // Process 0 automatically sends 'elements_per_proc' items to Process 1, Process 2, etc.
    MPI_Scatter(array, elements_per_proc, MPI_INT, sub_array, elements_per_proc, MPI_INT, 0, MPI_COMM_WORLD);

    // Step 3: Compute the local sum. Every process does this at the exact same time!
    for (int i = 0; i < elements_per_proc; i++) {
        local_sum += sub_array[i];
    }

    // Display the sum calculated by this specific process
    printf("Processor %d - Partial Sum: %d\n", rank, local_sum);

    // Step 4: Reduce (gather and combine) all the partial sums.
    // 'MPI_SUM' tells it to add all the 'local_sum's together and store it in 'total_sum' at Process 0.
    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Finally, the Master process prints the final combined total
    if (rank == 0) {
        printf("Total Sum: %d\n", total_sum);
    }

    free(sub_array);
    // Close the MPI environment safely
    MPI_Finalize();
    return 0;
}