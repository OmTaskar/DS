# 'import random' brings in a built-in Python tool that lets us pick random numbers.
import random

# Practical 4: Clock Synchronization (Berkeley Algorithm Simulation)
# This simulates how computers on a network sync their internal clocks.

# 'class' is used to create a blueprint for an object. Here, a 'Node' represents a computer.
class Node:
    
    # 'def' creates a function. '__init__' is a special function that runs automatically when a Node is created.
    # 'self' refers to the specific computer being created right now.
    def __init__(self, node_id, clock_time):
        self.node_id = node_id           # Save the computer's ID (like 1, 2, or 3)
        self.clock_time = clock_time     # Save the computer's current time

    # A simple function to give back the computer's current time when asked
    def get_time(self):
        return self.clock_time

    # A function to fix the clock by adding or subtracting an offset
    def adjust_time(self, offset):
        self.clock_time += offset

    # '__repr__' is a special function that tells Python how to print this object nicely
    def __repr__(self):
        return f"Node {self.node_id}: {self.clock_time:.2f} sec"


# Coordinator is a special kind of Node. It's the "Master" computer.
# Putting '(Node)' means it inherits everything from the Node blueprint above.
class Coordinator(Node):
    
    # This is the main function where the Berkeley algorithm happens
    def synchronize_clocks(self, nodes):
        print("Polling times from all nodes...")
        
        # '{}' creates an empty dictionary (like a list where every item has a label)
        times = {} 

        # 'for node in nodes:' is a loop that goes through every computer one by one
        for node in nodes:
            
            # If the computer we are looking at is OURSELVES (the coordinator), skip it
            if node.node_id == self.node_id:
                continue # 'continue' means skip to the next one in the loop
                
            # 'random.uniform(0.1, 0.5)' picks a random number between 0.1 and 0.5
            # This fakes the delay of sending a message over the internet
            delay = random.uniform(0.1, 0.5)
            
            # We calculate what time the node actually sent it, considering the delay
            node_time = node.get_time() + delay / 2
            
            # We save how many seconds difference there is between the node and the Coordinator
            times[node.node_id] = node_time - self.clock_time
            print(f"Node {node.node_id} time: {node.get_time():.2f}, adjusted for delay: {node_time:.2f}")

        # The Coordinator is exactly 0 seconds away from itself
        times[self.node_id] = 0.0

        # 'sum()' adds up all the differences. 'len()' counts how many computers there are.
        # Dividing them gives us the average time difference.
        average_offset = sum(times.values()) / len(times)
        print(f"\nCalculated average offset: {average_offset:.2f} seconds")

        # Now we loop through all the computers again
        for node in nodes:
            # We calculate how much this specific computer needs to change its clock
            offset = average_offset - times[node.node_id]
            
            # We call the function to adjust its clock
            node.adjust_time(offset) 
            print(f"Adjusting Node {node.node_id} by {offset:+.2f} seconds")

        print("\nSynchronization complete.\n")


# This is a special Python check. It means "Only run the code below if we run this file directly"
if __name__ == "__main__":
    
    # '[]' creates a List. We are creating 5 computers and putting them in a list called 'nodes'
    nodes = [
        Coordinator(0, 100.0),   # ID 0 is the Coordinator, time is 100.0
        Node(1, 102.0),          # ID 1 is a normal computer, time is 102.0
        Node(2, 98.5),           
        Node(3, 101.2),
        Node(4, 99.8),
    ]

    print("Initial times:")
    # Loop through the list and print each computer
    for node in nodes:
        print(node)

    # Grab the very first item in the list (index 0) and make it the coordinator
    coordinator = nodes[0]
    
    # Tell the coordinator to start the algorithm and fix everyone's clocks
    coordinator.synchronize_clocks(nodes)

    print("Final times after synchronization:")
    # Print everyone again to show they are now perfectly synced
    for node in nodes:
        print(node)