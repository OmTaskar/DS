//What it is: The main program that runs on the server side.
// Naming is used to bind (register) our service to a specific URL name
import java.rmi.Naming;
// LocateRegistry is used to start the RMI registry (the phonebook for services)
import java.rmi.registry.LocateRegistry;

public class ArithmeticServer {
    public static void main(String[] args) {
        try {
            // Start RMI registry on default port 1099.
            LocateRegistry.createRegistry(1099);

            // Create an instance of our actual math logic
            ArithmeticServiceImpl arithmeticService = new ArithmeticServiceImpl();

            // Bind (register) our service object to a specific URL name in the registry.
            // The client will use this exact string ("rmi://localhost/ArithmeticService") to find it.
            Naming.rebind("rmi://localhost/ArithmeticService", arithmeticService);

            System.out.println("Arithmetic Server is ready and waiting for client connections...");
        } catch (Exception e) {
            e.printStackTrace(); // Print any errors if something goes wrong
        }
    }
}