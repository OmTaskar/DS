import java.rmi.Naming; //It helps a client find and connect to a remote object/server.
import java.util.Scanner;

public class ArithmeticClient {
    public static void main(String[] args) {
        try {
            ArithmeticService arithmeticService =
                (ArithmeticService) Naming.lookup( //Naming.lookup() searches for the remote object from RMI Registry
                    "rmi://localhost/ArithmeticService" // The URL must perfectly match what the server used in 'rebind'
                );//This code connects the client to the remote ArithmeticService object stored in the RMI Registry.


            Scanner scanner = new Scanner(System.in);

            // Ask the user to input the numbers locally on their machine
            System.out.print("Enter the first number: ");
            double num1 = scanner.nextDouble();

            System.out.print("Enter the second number: ");
            double num2 = scanner.nextDouble();

            System.out.println("\nChoose an operation:");
            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.print("Enter your choice (1-4): ");
            int choice = scanner.nextInt();

            double result = 0;
            
            // Here is the magic part: When we call arithmeticService.add(num1, num2), 
            // the client actually sends num1 and num2 over the network to the server.
            // The server does the calculation, and sends the answer back to "result".
            switch (choice) {
                case 1: result = arithmeticService.add(num1, num2); break;
                case 2: result = arithmeticService.subtract(num1, num2); break;
                case 3: result = arithmeticService.multiply(num1, num2); break;
                case 4: result = arithmeticService.divide(num1, num2); break;
                default:
                    System.out.println("Invalid choice");
                    return;
            }

            // Print the result we got back from the server
            System.out.println("Result: " + result);
            scanner.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}