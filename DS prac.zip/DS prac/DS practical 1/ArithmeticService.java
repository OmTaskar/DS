//What it is: This file is an interface. It acts as an agreement between the client and the server.
//What it does: It lists all the methods the server promises to provide (add, subtract, multiply, divide)
// in this interface can be called from another computer over the network.

import java.rmi.Remote;

// RemoteException handles any network errors (like server crashes, disconnected Wi-Fi, etc.)
import java.rmi.RemoteException;

// We must extend 'Remote' so the client knows it can access this across the network.
public interface ArithmeticService extends Remote {
    
    // Every method must 'throw RemoteException' because network communication can fail at any time.
    double add(double a, double b) throws RemoteException;
    double subtract(double a, double b) throws RemoteException;
    double multiply(double a, double b) throws RemoteException;
    double divide(double a, double b) throws RemoteException;
}
