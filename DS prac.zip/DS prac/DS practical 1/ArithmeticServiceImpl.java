//What it is: This is the implementation of the interface above.
//What it does: This file contains the actual code that performs the math. When the client asks to add two numbers, the var1 + var3 code inside this file is what actually runs.
//Why it's needed: It extends UnicastRemoteObject, which is a special Java class that allows this object to actively listen for incoming network requests from clients.

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ArithmeticServiceImpl extends UnicastRemoteObject implements ArithmeticService {
   
   public ArithmeticServiceImpl() throws RemoteException {
       super(); // Calls parent constructor to set up network connection
   }

   // Actual logic for addition
   public double add(double var1, double var3) throws RemoteException {
      return var1 + var3;
   }

   // Actual logic for subtraction
   public double subtract(double var1, double var3) throws RemoteException {
      return var1 - var3;
   }

   // Actual logic for multiplication
   public double multiply(double var1, double var3) throws RemoteException {
      return var1 * var3;
   }

   // Actual logic for division, handles divide-by-zero error
   public double divide(double var1, double var3) throws RemoteException {
      if (var3 == 0.0) {
         throw new RemoteException("Cannot divide by zero");
      } else {
         return var1 / var3;
      }
   }
}