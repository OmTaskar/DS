# 'threading' is a Python tool that lets multiple tasks run at the exact same time
import threading
# 'time' is a Python tool that lets us pause the program using 'time.sleep()'
import time

# Practical 5: Mutual Exclusion (Token Ring Algorithm)
# Only the process holding the Token is allowed to "ENTER critical section" (use the printer).

# 'class' defines our blueprint for the TokenRing system
class TokenRing:
    
    # '__init__' is the setup function that runs right when we create a TokenRing
    # 'self' refers to this TokenRing object.
    def __init__(self, num_processes):
        self.num_processes = num_processes # Save the total number of computers
        self.current_holder = 0            # Computer 0 starts holding the token
        self.running = True                # A True/False flag used to keep the program running

    # This function is what every individual computer will do
    def process(self, process_id):
        
        # 'while self.running:' means "keep repeating the code below forever, until I say stop"
        while self.running:
            
            # 'if' is a condition. It asks: Is my computer's ID equal to the person holding the token?
            if self.current_holder == process_id:
                
                # I have the token! I can enter the critical section.
                print(f"Process {process_id} ENTERING critical section")
                
                # 'time.sleep(1)' makes Python pause for 1 second (faking that it is printing a page)
                time.sleep(1) 
                
                print(f"Process {process_id} EXITING critical section\n")

                # I am done. Pass the token to the NEXT process in the ring.
                # The '%' symbol means 'remainder'. If we have 5 computers (0,1,2,3,4),
                # and computer 4 passes it, 4+1 is 5. 5 divided by 5 has a remainder of 0.
                # So it safely loops back to computer 0!
                self.current_holder = (process_id + 1) % self.num_processes

            # If I don't have the token, just pause for half a second, then loop back up and check again.
            time.sleep(0.5)

    # This function turns on the whole system
    def start(self):
        # '[]' creates an empty list. We will put our running threads in here.
        threads = []

        # 'for i in range(...):' loops from 0 up to the number of processes we want
        for i in range(self.num_processes):
            
            # Here we tell Python to run our 'process()' function in the background as a "Thread"
            t = threading.Thread(target=self.process, args=(i,))
            
            # Add it to our list
            threads.append(t)
            
            # Start it running!
            t.start()

        # 'input()' stops the program and waits for the user to type something and press Enter
        input("Press ENTER to stop...\n")
        
        # Once the user presses Enter, we change 'running' to False.
        # This tells all the 'while self.running:' loops up above to stop!
        self.running = False 

        # 'for t in threads:' goes through all the running background tasks
        for t in threads:
            # '.join()' safely waits for them to finish their current job before closing them
            t.join()


# ---- MAIN PROGRAM ----
# 'input()' asks the user a question. 
# 'int()' takes their typed answer and converts it into a Number (Integer)
num = int(input("Enter number of processes: "))

# Create a new TokenRing using the number they typed in
ring = TokenRing(num)

# Start the ring!
ring.start()