// Import required modules
const express = require('express');
const cors = require('cors');

// Create the Express web server
const app = express();

// Middleware to allow cross-origin requests (so the client can talk to the server)
app.use(cors());
// Middleware to parse incoming JSON data from the client
app.use(express.json());
// Serve the frontend HTML file automatically from the "public" folder
app.use(express.static('public'));

// --- THE WEB SERVICE (REST API) ---
// This endpoint listens for HTTP POST requests at the URL '/calculate'
app.post('/calculate', (req, res) => {
    // 1. Receive data (JSON) from the client
    const { num1, num2, operation } = req.body;
    let result = 0;

    // 2. Process the data (Server-side logic)
    switch (operation) {
        case 'add': result = num1 + num2; break;
        case 'subtract': result = num1 - num2; break;
        case 'multiply': result = num1 * num2; break;
        case 'divide': 
            if (num2 === 0) {
                // If division by zero, return an HTTP 400 Bad Request error
                return res.status(400).json({ error: 'Division by zero is not allowed' });
            }
            result = num1 / num2; 
            break;
        default: 
            return res.status(400).json({ error: 'Invalid operation' });
    }

    // 3. Send the result back to the client in JSON format
    res.json({ result: result });
});

// Start the server and listen on port 3000
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
    console.log(`Open your browser and go to http://localhost:${PORT} to view the Client Application!`);
});
